export const calculator = {
    suma(a,b) {
        return a + b;
    },

    resta(a,b) {
        return a-b;
    },

    multiplicacion(a,b){
        return a*b;
    },
    division(a,b){
        return a/b;
    }
}